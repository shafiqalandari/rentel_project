import React from 'react';
import { LayoutDashboard, Store, Users, FileText, WalletCards, ReceiptText, Handshake, HandCoins, Landmark, PieChart, BarChart3, Settings } from 'lucide-react';

const icons = {
  dashboard: LayoutDashboard,
  shops: Store,
  tenants: Users,
  contracts: FileText,
  charges: WalletCards,
  expenses: ReceiptText,
  partners: Handshake,
  withdrawals: HandCoins,
  accounts: Landmark,
  distributions: PieChart,
  reports: BarChart3,
  settings: Settings,
} as const;

export function SidebarIcon({name}: {name: string}) {
  const Icon = icons[name as keyof typeof icons] ?? FileText;
  return <Icon className="sidebar-nav-icon" size={19} strokeWidth={1.85} aria-hidden="true" />;
}
